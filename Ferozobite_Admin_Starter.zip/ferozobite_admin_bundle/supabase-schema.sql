-- Run this in Supabase SQL Editor.
create extension if not exists pgcrypto;
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'customer' check (role in ('admin','customer')),
  created_at timestamptz not null default now()
);
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text not null default '',
  price_pkr numeric(10,2) not null default 0 check (price_pkr >= 0),
  pieces_per_box integer not null default 10 check (pieces_per_box > 0),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_name text,
  customer_phone text,
  delivery_address text,
  items jsonb not null default '[]'::jsonb,
  total_pkr numeric(10,2) not null default 0 check (total_pkr >= 0),
  status text not null default 'new' check (status in ('new','confirmed','preparing','out_for_delivery','completed','cancelled')),
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
-- Role check helper: admin is assigned explicitly by the project owner in SQL.
create or replace function public.is_ferozo_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin'); $$;
revoke all on function public.is_ferozo_admin() from public;
grant execute on function public.is_ferozo_admin() to authenticated;
-- Anyone may read active products; only admins may create/edit/delete products.
drop policy if exists "Public can read active products" on public.products;
create policy "Public can read active products" on public.products for select using (active = true or public.is_ferozo_admin());
drop policy if exists "Admins manage products" on public.products;
create policy "Admins manage products" on public.products for all to authenticated using (public.is_ferozo_admin()) with check (public.is_ferozo_admin());
-- Only admins can read/manage orders. Public checkout integration should use a carefully validated server-side function, not broad public insert access.
drop policy if exists "Admins manage orders" on public.orders;
create policy "Admins manage orders" on public.orders for all to authenticated using (public.is_ferozo_admin()) with check (public.is_ferozo_admin());
drop policy if exists "Users read own profile" on public.profiles;
create policy "Users read own profile" on public.profiles for select to authenticated using (id = auth.uid() or public.is_ferozo_admin());
-- Seed the current website's two products (safe to run more than once by name).
insert into public.products(name,description,price_pkr,pieces_per_box,active)
select 'Chicken Rolls','Premium unfried frozen chicken rolls.',857,10,true
where not exists (select 1 from public.products where name='Chicken Rolls');
insert into public.products(name,description,price_pkr,pieces_per_box,active)
select 'Chicken Samosas','Premium unfried frozen chicken samosas.',857,10,true
where not exists (select 1 from public.products where name='Chicken Samosas');
