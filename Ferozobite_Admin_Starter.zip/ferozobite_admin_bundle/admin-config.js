// Add your Supabase Project URL and anon/publishable key here.
// Safe for browser use only with the anon/publishable key and correct RLS policies.
// NEVER paste your service_role/secret key here.
window.FEROZO_CONFIG = {
  url: 'YOUR_SUPABASE_PROJECT_URL',
  anonKey: 'YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY'
};
