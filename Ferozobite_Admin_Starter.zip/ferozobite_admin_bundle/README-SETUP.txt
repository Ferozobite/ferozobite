FEROZO BITES WEBSITE + ADMIN PANEL STARTER

Files:
- index.html: original website from Index00.zip (preserved)
- admin.html: admin sign-in and product/order dashboard
- admin-config.js: configure Supabase URL and anon/publishable key
- supabase-schema.sql: tables and Row Level Security policies

IMPORTANT STATUS
This bundle is a starter, not yet a live deployment. The original website currently builds a cart and sends order details to WhatsApp. It does NOT write orders to a database. The admin dashboard can manage database products after setup, but public index.html is not yet wired to load its product prices from the database. Orders will not show up until checkout is integrated safely.

SETUP
1. Create a Supabase project.
2. Open SQL Editor and run supabase-schema.sql.
3. In Authentication > Users, create the admin user with email/password.
4. Copy that user's UUID. In SQL Editor run:
   insert into public.profiles (id, role) values ('PASTE-ADMIN-USER-UUID-HERE', 'admin')
   on conflict (id) do update set role='admin';
5. In Project Settings > API, copy Project URL and anon/publishable key into admin-config.js. Do NOT use a service_role/secret key in browser files.
6. Upload all four files to the same website deployment. Visit /admin.html to sign in.
7. Before treating this as complete, integrate index.html with the products table and add a server-side validated checkout/order-creation function. Do not enable unrestricted public order inserts.

DEPLOYMENT
For GitHub + Netlify: upload these files to the repository root and commit/push. Netlify should publish the repository root; set the publish directory to the folder containing index.html. Deploy, then test the website URL and /admin.html. This requires the user's GitHub/Netlify account action and credentials; this bundle does not deploy itself.
